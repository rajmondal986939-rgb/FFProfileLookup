package com.example.ffprofilelookup;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private int bg = Color.rgb(16, 25, 35);
    private int panel = Color.rgb(31, 45, 59);
    private int mint = Color.rgb(56, 217, 169);
    private int white = Color.rgb(245, 248, 252);
    private int muted = Color.rgb(170, 188, 204);
    private EditText uidInput;
    private TextView status, profileUid, playerName, likes;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(bg);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(28), dp(22), dp(24));
        scroll.addView(root);
        setContentView(scroll);

        TextView eyebrow = text("PLAYER LOOKUP • ANDROID", 12, mint, true);
        root.addView(eyebrow, params(-1, -2, 0, 0, 0, 8));

        TextView title = text("FF PROFILE
LOOKUP", 30, white, true);
        title.setLineSpacing(dp(1), 1f);
        root.addView(title, params(-1, -2, 0, 0, 0, 8));

        TextView intro = text("Enter a player UID to start a profile lookup.", 15, muted, false);
        root.addView(intro, params(-1, -2, 0, 0, 0, 24));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(18), dp(16), dp(18));
        card.setBackground(round(panel, 18));
        root.addView(card, params(-1, -2, 0, 0, 0, 16));

        card.addView(text("PLAYER UID", 12, muted, true), params(-1, -2, 0, 0, 0, 8));
        uidInput = new EditText(this);
        uidInput.setSingleLine(true);
        uidInput.setHint("Enter numeric UID");
        uidInput.setHintTextColor(Color.rgb(118, 139, 157));
        uidInput.setTextColor(white);
        uidInput.setTextSize(16);
        uidInput.setInputType(2);
        uidInput.setPadding(dp(12), dp(12), dp(12), dp(12));
        uidInput.setBackground(round(Color.rgb(18, 30, 42), 10));
        card.addView(uidInput, params(-1, dp(52), 0, 0, 0, 14));

        Button search = new Button(this);
        search.setText("SEARCH PROFILE");
        search.setTextColor(bg);
        search.setTextSize(14);
        search.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        search.setAllCaps(false);
        search.setBackground(round(mint, 12));
        card.addView(search, params(-1, dp(52), 0, 0, 0, 0));

        LinearLayout result = new LinearLayout(this);
        result.setOrientation(LinearLayout.VERTICAL);
        result.setPadding(dp(16), dp(16), dp(16), dp(16));
        result.setBackground(round(panel, 18));
        root.addView(result, params(-1, -2, 0, 0, 0, 16));

        result.addView(text("PROFILE RESULT", 12, mint, true), params(-1, -2, 0, 0, 0, 12));
        playerName = text("Player name: —", 16, white, true);
        result.addView(playerName, params(-1, -2, 0, 0, 0, 10));
        profileUid = text("UID: —", 14, muted, false);
        result.addView(profileUid, params(-1, -2, 0, 0, 0, 10));
        likes = text("Likes: —", 14, muted, false);
        result.addView(likes, params(-1, -2, 0, 0, 0, 10));
        status = text("Status: Ready for lookup", 13, muted, false);
        result.addView(status, params(-1, -2, 0, 0, 0, 0));

        TextView note = text("Note: This starter app does not connect to Free Fire or create likes. Real profile data needs an authorized data source.", 12, muted, false);
        note.setLineSpacing(dp(3), 1f);
        root.addView(note, params(-1, -2, 2, 4, 2, 0));

        search.setOnClickListener(v -> {
            String uid = uidInput.getText().toString().trim();
            if (!uid.matches("[0-9]{5,20}")) {
                status.setText("Status: Enter a numeric UID (5–20 digits).");
                status.setTextColor(Color.rgb(255, 180, 171));
                return;
            }
            profileUid.setText("UID: " + uid);
            playerName.setText("Player name: Not connected");
            likes.setText("Likes: Unavailable");
            status.setText("Status: UID saved locally. Connect an authorized API to retrieve real data.");
            status.setTextColor(mint);
        });
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private LinearLayout.LayoutParams params(int w, int h, int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w < 0 ? w : dp(w), h < 0 ? h : dp(h));
        p.setMargins(dp(left), dp(top), dp(right), dp(bottom));
        return p;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
