# FF Profile Lookup — Android starter project

This is a safe Android starter app for entering a Free Fire UID and displaying lookup status.

## Important limitation
The app does **not** fetch real Free Fire profile data or generate likes. Real profile information requires a verified, authorized data source/API. No game-server requests, credentials, or automation are included.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Install the generated APK on your Android device.

This source project has not been compiled into an APK in this environment.
